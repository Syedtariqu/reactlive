## Exercise 2 - Creating a `MenuSection` component

In the "drawing boxes" exercise in class, we learned that repeated chunks of markup should be components; so let's create one!

Create two new files, `src/components/MenuSection.js` and `src/components/MenuSection.css`. Write the following into the .js file

> **✋ Please do NOT copy/paste!** You'll write _a lot_ of new components over this module. It's worth taking the time to get used to writing them out.

```jsx
import './MenuSection.css';

const MenuSection = ({foods}) => {
  return <div className='container'></div>;
};

export default MenuSection;
```

Inside `Menu`, we're mapping through each appetizer in the array. Pass that array along to the `MenuSection` instance:

```jsx
// Inside Menu
return (
    <MenuSection foods={data.appetizers} />
)
```

Next, update the `MenuSection` component to render each individual food's:

- name
- price
- description

Add some styles and a title prop to make it look like a menu. 

How you structure this exactly is up to you, but you should wind up with something similar to this image:

![food list with some styling](/__lecture/assets/new/exercise-2-result.png)

It's up to you how to structure the HTML content of `MenuSection`, which CSS properties to use.

[Back to the README.md](../README.md)
