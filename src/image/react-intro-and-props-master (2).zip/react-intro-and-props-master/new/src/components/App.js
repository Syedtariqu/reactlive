import Header from "./Header";
import Menu from "./Menu";

import data from "../data";

import "./App.css";

const App = () => {
    
    return (
        <div className="wrapper">
            <Header />
            <Menu />
        </div>
    );
};

export default App;
