import "./Menu.css";

const Menu = () => {
    return (
        <div>Help me create my menu please 🥺</div>
    )
}

export default Menu