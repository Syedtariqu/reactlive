# Intro to React & Props

## 🦊 Pre-lecture

⏲️ _Estimated time required: 30 minutes._

- Take a look at the React.Js site. (You might want to bookmark this for the remainder of the bootcamp. https://reactjs.org/

---

## 🦉 Lecture

- [lecture-1-intro.md](__lecture/lecture-1-intro.md)
- [lecture-2-props.md](__lecture/lecture-2-props.md)
- [lecture-3-modules.md](__lecture/lecture-3-modules.md)

Keep in mind that these slides are not interactive, like in the actual lecture. Whenever possible, we will provide links to working code examples in CodeSandbox.

---

## Understanding the structure of the repo

This workshop is going to be structured a bit uniquely. There are 2 folders in this repo: `original`, and `new`.

The `original` folder contains the original workshops designed by Scott and Josh a few years ago. I didn't want to get rid of it ~~yet~~ so I've kept it under a folder labelled `original`.

The `new` folder contains a totally new workshop designed by me. It will still be a challenge, but overall it should be easier than the original workshop.

As all of you from `cb-wd-16` are going to be our pilot cohort for this change, you can choose which one you want to work on and submit for this workshop. Whichever one you choose, you must still follow the instructions and hit the appropriate checkpoint, just as we've always done.

You can work on both if you want, but before you do check out this [link](https://journeyeducation.notion.site/Mental-Health-Stress-Management-64e3afdbecef42a090c6c350dc250044).

[Go to the new workshop](/new/README.md)

[Go to the original workshop](/original/README.md)