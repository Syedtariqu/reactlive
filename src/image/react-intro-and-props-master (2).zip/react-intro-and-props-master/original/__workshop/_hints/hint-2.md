```diff
const App = (props) => {
  return (
    <div className="wrapper">
      <Header />
-      <ChatStream messages={props.conversation.messages} />
+      <ChatStream
+        messages={props.conversation.messages}
+        currentUser={props.currentUser}
+      />
      <Footer />
    </div>
  );
}
```

[Back to exercise-3.md](../exercise-3.md)