# Exercise 5 - Adding Bubble "tips"

In iMessage, the chat bubbles have little tips, to make them look like speech bubbles in a comic book:

![sent/received styles](/__lecture/assets/original/exercise-3-with-tips.png)

Two images are made available in the `public/assets` folder

- `tip-sent.svg`
- `tip-received.svg`

Use an `<img>` tag to add these to the ChatMessage components. _TIP_: the `src` attributes will be "/assets/tip-sent.svg" and "/assets/tip-received.svg".

[Back to the README.md](../README.md)
