import "./SentMessage.css";

const SentMessage = (props) => {
  return (
    <div className="chat">
      <div className="sentchatMessage" key={props.message.id}>
        <div className="sentMsg">
          <p>{props.message.body}</p>
          <time>{props.message.timestamp}</time>
        </div>
        <img className="senttipIcon" src="assets/tip-sent.svg"/>
      </div>
    </div>
  );
};

export default SentMessage;
