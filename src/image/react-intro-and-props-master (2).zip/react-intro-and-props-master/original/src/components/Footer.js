import "./Footer.css";

const Footer = (props) => {
  return <footer>
    <div className="bottom">
      <div className="cup">
        <textarea id="message" cols="30" rows="1" placeholder="Message..." />
        <button className="send">Send</button>
      </div>
    </div>
  </footer>;
};

export default Footer;
