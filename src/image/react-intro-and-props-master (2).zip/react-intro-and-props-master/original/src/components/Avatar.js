import "./Avatar.css";

const Avatar = (props) => {
  return (
    <div>
      <img    alt="User image"
              className="avatar"
              src={props.src}
              height={props.height}
              width={props.width}
              draggable="false" />
    </div>
  );
};

export default Avatar;
