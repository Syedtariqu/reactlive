import "./ChatMessage.css";
import Avatar from "./Avatar";

const ReceivedMessage = (props) => {
  return (
    <div className="chat">
      <div className="chatMessage" key={props.message.id}>
        <Avatar height="40" width="40" src={props.message.user.avatar}/>
        <div className="msg">
          <p className="username">{props.message.user.username}</p>
          <p>{props.message.body}</p>
          <time>{props.message.timestamp}</time>
        </div>
        <img className="receivedtipIcon" src="assets/tip-received.svg"/>
      </div>
    </div>
  );
};

export default ReceivedMessage;
