import "./Header.css";
import Avatar from "./Avatar";

const Header = (props) => {
  return <header>{
    props.filteredUsers.map(user => {
      return (<div className="flexCol">
        <Avatar src={user.avatar} height="100" widht="100" />
        <div>{user.username}</div>
      </div>);
    })
  }</header>;
};

export default Header;
