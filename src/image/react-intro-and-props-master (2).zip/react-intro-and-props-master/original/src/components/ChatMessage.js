import "./ChatMessage.css";
import SentMessage from "./SentMessage";
import RecievedMessage from "./RecievedMessage";

const ChatMessage = (props) => {
  return (
    <>
      {props.isCurrentUserMessage ? <SentMessage message={props.message} /> : <RecievedMessage message={props.message} />}
    </>

  );
};

export default ChatMessage;
